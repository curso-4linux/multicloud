<?php

/**
 * Fired when the plugin is uninstalled.
 *
 * @package Edwiser Bridge
 *
 * @link       https://edwiser.org
 * @since      1.0.0
 * /
